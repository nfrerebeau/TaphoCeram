library(testthat)
library(khroma)

test_check("khroma")
