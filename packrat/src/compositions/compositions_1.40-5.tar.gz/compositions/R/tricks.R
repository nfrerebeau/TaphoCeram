
gsi.mystructure = function(x, ...){
  if(is.null(x)) return(x)
  else return(structure(x, ...))
}
  